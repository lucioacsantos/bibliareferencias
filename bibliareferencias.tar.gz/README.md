# BibliaReferencias
Bíblia com referências entre os versículos bíblicos.
