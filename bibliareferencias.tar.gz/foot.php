<?php
/**
*** 99242991 | Lúcio ALEXANDRE Correia dos Santos
**/

?>

<!-- FOOTER -->
        <footer class="container">
            <p class="float-right"><a href="#">Back to top</a></p>
            <p>2020 Bíblia Referências. &middot; <a href="http://sites.google.com/site/biblialivre" target="_blanck">
                Bíblia Livre</a> &middot; 
                <a href="https://creativecommons.org/licenses/by/3.0/br/" target="_blanck">
                Creative Commons Atribution 3.0 Brasil</a> &middot; 
                <a href="https://br.freepik.com/fotos/acondicionamento">br.freepik.com</a>
            </p>
        </footer>
    </main>
    <?php
    echo"
    <script src=\"$url/js/jquery-3.5.1.slim.min.js\"></script>
    <script>
        window.jQuery || document.write('<script src=\"$url/js/jquery.slim.min.js\"><\/script>')
    </script>
    <script src=\"$url/js/bootstrap.bundle.min.js\"></script>";
    ?>

</html>